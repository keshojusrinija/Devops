function ProductCard({ name, price, image, rating, onAdd }) {
  return (
    <div className="card">
      <img src={image} alt={name} className="product-img" />

      <h3>{name}</h3>

      <p className="rating">⭐ {rating}</p>

      <p className="price">₹ {price}</p>

      <button onClick={onAdd}>Add to Cart</button>
    </div>
  );
}

export default ProductCard;
