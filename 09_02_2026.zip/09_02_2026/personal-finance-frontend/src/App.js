import React from 'react';
import Expenses from './Expenses';
import './App.css';

const App = () => {
  return (
    <div className="App">
      <Expenses />
    </div>
  );
};

export default App;
