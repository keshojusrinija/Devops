const productService = require('../services/productService');

// CREATE
exports.createProduct = async (req, res) => {
  try {
    const product = await productService.createProduct(req.body);
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};

// READ ALL
exports.getProducts = async (req, res) => {
  const products = await productService.getAllProducts();
  res.json(products);
};

// READ ONE
exports.getProduct = async (req, res) => {
  const product = await productService.getProductById(req.params.id);
  if (!product)
    return res.status(404).json({ message: 'Product not found' });

  res.json(product);
};

// UPDATE
exports.updateProduct = async (req, res) => {
  const product = await productService.updateProduct(req.params.id, req.body);
  if (!product)
    return res.status(404).json({ message: 'Product not found' });

  res.json(product);
};

// DELETE
exports.deleteProduct = async (req, res) => {
  const product = await productService.deleteProduct(req.params.id);
  if (!product)
    return res.status(404).json({ message: 'Product not found' });

  res.json({ message: 'Product deleted successfully' });
};
