# 🏗️ Production Best Practices & Architecture Guide

## Table of Contents
- [Architecture Overview](#architecture-overview)
- [Security Best Practices](#security-best-practices)
- [Performance Optimization](#performance-optimization)
- [Deployment Strategies](#deployment-strategies)
- [Monitoring & Logging](#monitoring--logging)
- [Scaling Considerations](#scaling-considerations)

---

## 🏛️ Architecture Overview

### Current Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Docker Build Process                      │
├─────────────────────────────────────────────────────────────┤
│  Stage 1: Build (node:18-alpine)                            │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 1. Install dependencies (npm ci)                     │   │
│  │ 2. Copy source code                                  │   │
│  │ 3. Inject REACT_APP_API_URL via build arg           │   │
│  │ 4. Build React app (npm run build)                  │   │
│  │ 5. Output: /app/build with optimized static files   │   │
│  └──────────────────────────────────────────────────────┘   │
│                            ↓                                 │
│  Stage 2: Serve (nginx:alpine)                              │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ 1. Copy /app/build → /usr/share/nginx/html         │   │
│  │ 2. Configure nginx for SPA routing                  │   │
│  │ 3. Enable gzip, caching, security headers           │   │
│  │ 4. Expose port 80                                   │   │
│  │ 5. Final image size: ~40MB                          │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘

                            ↓

┌─────────────────────────────────────────────────────────────┐
│                    Runtime Architecture                      │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│   User Browser                                               │
│        ↓                                                     │
│   [Port 80/443]                                             │
│        ↓                                                     │
│   Docker Container (nginx:alpine)                           │
│        ├─→ Static Files (HTML, CSS, JS)                    │
│        ├─→ SPA Routing (fallback to index.html)            │
│        └─→ Gzip Compression & Caching                      │
│                                                              │
│   React App (in browser)                                    │
│        ↓                                                     │
│   API Service (api.js)                                      │
│        ├─→ Validate REACT_APP_API_URL                      │
│        ├─→ Axios HTTP Client                               │
│        └─→ Error Handling & Logging                        │
│                                                              │
│        ↓                                                     │
│   Backend API (separate service)                            │
│   [http://localhost:8080/api or https://api.myapp.com/api] │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

### Why Multi-Stage Build?

| Aspect | Without Multi-Stage | With Multi-Stage |
|--------|-------------------|------------------|
| **Image Size** | ~180MB (includes Node.js) | ~40MB (only nginx) |
| **Security** | Source code exposed | Only built assets |
| **Build Tools** | Included in production | Not included |
| **Attack Surface** | Large | Minimal |
| **Startup Time** | Slower | Faster |

---

## 🔒 Security Best Practices

### ✅ What We've Implemented

1. **No Source Code in Production Image**
   - Multi-stage build removes source code
   - Only compiled/minified assets in final image

2. **Security Headers (nginx.conf)**
   ```nginx
   add_header X-Frame-Options "SAMEORIGIN" always;
   add_header X-Content-Type-Options "nosniff" always;
   add_header X-XSS-Protection "1; mode=block" always;
   add_header Referrer-Policy "no-referrer-when-downgrade" always;
   ```

3. **Minimal Base Image**
   - Using `alpine` variants (smaller attack surface)
   - Regular security updates via `apk`

4. **No Hardcoded Secrets**
   - API URL passed at build time
   - No credentials in source code

### 🔐 Additional Recommendations

#### 1. Content Security Policy (CSP)

Add to `nginx.conf`:
```nginx
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' https://api.myapp.com;" always;
```

#### 2. HTTPS Enforcement

```nginx
# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name myapp.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name myapp.com;
    
    ssl_certificate /etc/nginx/ssl/cert.pem;
    ssl_certificate_key /etc/nginx/ssl/key.pem;
    
    # ... rest of config
}
```

#### 3. Rate Limiting

```nginx
# In nginx.conf
limit_req_zone $binary_remote_addr zone=api_limit:10m rate=10r/s;

location /api {
    limit_req zone=api_limit burst=20 nodelay;
    proxy_pass http://backend;
}
```

#### 4. Run as Non-Root User

Add to Dockerfile:
```dockerfile
# Create nginx user
RUN addgroup -g 101 -S nginx && \
    adduser -S -D -H -u 101 -h /var/cache/nginx -s /sbin/nologin -G nginx -g nginx nginx

USER nginx
```

#### 5. Environment Variable Security

**Don't expose sensitive data in React:**
```javascript
// ❌ BAD - Exposes API keys in browser
const API_KEY = process.env.REACT_APP_API_KEY;

// ✅ GOOD - Use backend for sensitive operations
const response = await authenticatedRequest();
```

---

## ⚡ Performance Optimization

### ✅ What We've Implemented

1. **Gzip Compression**
   - Reduces payload size by ~70%
   - Configured in nginx.conf

2. **Static Asset Caching**
   - 1 year cache for immutable assets
   - No cache for index.html (ensures updates)

3. **HTTP/2 Support Ready**
   - Nginx configured for HTTP/2
   - Requires HTTPS setup

### 🚀 Additional Optimizations

#### 1. Image Optimization

```dockerfile
# Optimize React build
ENV GENERATE_SOURCEMAP=false
ENV INLINE_RUNTIME_CHUNK=false

RUN npm run build -- --production
```

#### 2. Code Splitting

In React app:
```javascript
// Lazy load routes
import { lazy, Suspense } from 'react';

const Dashboard = lazy(() => import('./pages/Dashboard'));
const Transactions = lazy(() => import('./pages/Transactions'));

function App() {
  return (
    <Suspense fallback={<Loading />}>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/transactions" element={<Transactions />} />
      </Routes>
    </Suspense>
  );
}
```

#### 3. Bundle Size Analysis

```powershell
# Install bundle analyzer
npm install --save-dev webpack-bundle-analyzer

# Add to package.json scripts
"analyze": "source-map-explorer 'build/static/js/*.js'"

# Run analysis
npm run build
npm run analyze
```

#### 4. CDN Integration

```nginx
# Serve static assets from CDN
location ~* \.(jpg|jpeg|png|gif|ico|css|js|svg|woff|woff2|ttf|eot)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
    
    # Optional: Redirect to CDN
    # return 301 https://cdn.myapp.com$request_uri;
}
```

---

## 🚀 Deployment Strategies

### Strategy 1: Blue-Green Deployment

```powershell
# Deploy new version (green)
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t finance:v2 .
docker run -d --name finance-green -p 8080:80 finance:v2

# Test new version
curl http://localhost:8080/health

# Switch traffic (update load balancer or docker port)
docker stop finance-blue
docker rm finance-blue
docker run -d --name finance-blue -p 80:80 finance:v2

# Cleanup
docker stop finance-green
docker rm finance-green
```

### Strategy 2: Rolling Update (Docker Swarm/Kubernetes)

```yaml
# Kubernetes Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: finance-frontend
spec:
  replicas: 3
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    spec:
      containers:
      - name: frontend
        image: finance-frontend:v2
        ports:
        - containerPort: 80
```

### Strategy 3: Canary Deployment

```powershell
# 90% traffic to stable, 10% to canary
# Run stable version (3 replicas)
docker run -d --name finance-stable-1 -p 8081:80 finance:v1
docker run -d --name finance-stable-2 -p 8082:80 finance:v1
docker run -d --name finance-stable-3 -p 8083:80 finance:v1

# Run canary version (1 replica)
docker run -d --name finance-canary -p 8084:80 finance:v2

# Configure load balancer to distribute traffic
# Monitor metrics, gradually increase canary traffic
```

---

## 📊 Monitoring & Logging

### Application Logging

#### 1. Centralized Logging with Fluentd

```yaml
# docker-compose.yml
services:
  frontend:
    logging:
      driver: fluentd
      options:
        fluentd-address: localhost:24224
        tag: finance.frontend
```

#### 2. Log to External Service

```nginx
# nginx.conf - Custom log format
log_format json_combined escape=json
  '{'
    '"time_local":"$time_local",'
    '"remote_addr":"$remote_addr",'
    '"request":"$request",'
    '"status": "$status",'
    '"body_bytes_sent":"$body_bytes_sent",'
    '"request_time":"$request_time",'
    '"http_referrer":"$http_referer",'
    '"http_user_agent":"$http_user_agent"'
  '}';

access_log /var/log/nginx/access.log json_combined;
```

### Monitoring Endpoints

#### Health Check

```nginx
# Already implemented in nginx.conf
location /health {
    access_log off;
    return 200 "healthy\n";
    add_header Content-Type text/plain;
}
```

#### Metrics Endpoint

```nginx
location /metrics {
    stub_status on;
    access_log off;
    allow 127.0.0.1;
    deny all;
}
```

### Application Performance Monitoring (APM)

```javascript
// In src/index.js
import * as Sentry from '@sentry/react';

Sentry.init({
  dsn: process.env.REACT_APP_SENTRY_DSN,
  environment: process.env.REACT_APP_ENV,
  tracesSampleRate: 1.0,
});
```

### Docker Monitoring

```powershell
# View resource usage
docker stats finance-frontend-prod

# Export metrics
docker stats finance-frontend-prod --no-stream --format "{{.CPUPerc}}\t{{.MemUsage}}"

# Integration with Prometheus
# Use cAdvisor for container metrics
docker run -d \
  --name=cadvisor \
  -p 8080:8080 \
  -v /:/rootfs:ro \
  -v /var/run:/var/run:ro \
  -v /sys:/sys:ro \
  -v /var/lib/docker/:/var/lib/docker:ro \
  google/cadvisor:latest
```

---

## 📈 Scaling Considerations

### Horizontal Scaling

#### Load Balancer Configuration (nginx)

```nginx
upstream frontend_servers {
    least_conn;
    server frontend1:80 max_fails=3 fail_timeout=30s;
    server frontend2:80 max_fails=3 fail_timeout=30s;
    server frontend3:80 max_fails=3 fail_timeout=30s;
}

server {
    listen 80;
    
    location / {
        proxy_pass http://frontend_servers;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

#### Docker Swarm Scaling

```powershell
# Initialize swarm
docker swarm init

# Create service
docker service create \
  --name finance-frontend \
  --replicas 3 \
  --publish 80:80 \
  finance-frontend:v1

# Scale up/down
docker service scale finance-frontend=5
```

#### Kubernetes Horizontal Pod Autoscaler

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: finance-frontend-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: finance-frontend
  minReplicas: 2
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

### CDN Integration

```javascript
// Update public URLs to use CDN
// In package.json
{
  "homepage": "https://cdn.myapp.com"
}

// Or set PUBLIC_URL environment variable during build
PUBLIC_URL=https://cdn.myapp.com npm run build
```

### Database Considerations (for backend)

```javascript
// API service - connection pooling
const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000,
  maxRedirects: 5,
  // Connection pooling
  httpAgent: new http.Agent({ 
    keepAlive: true,
    maxSockets: 50 
  }),
});
```

---

## 🔄 CI/CD Integration

### GitHub Actions Example

```yaml
# .github/workflows/deploy.yml
name: Build and Deploy

on:
  push:
    branches: [main]

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Build Docker Image
        run: |
          docker build \
            --build-arg REACT_APP_API_URL=${{ secrets.API_URL }} \
            -t finance-frontend:${{ github.sha }} .
      
      - name: Run Tests
        run: |
          docker run --rm finance-frontend:${{ github.sha }} npm test
      
      - name: Push to Registry
        run: |
          echo ${{ secrets.DOCKER_PASSWORD }} | docker login -u ${{ secrets.DOCKER_USERNAME }} --password-stdin
          docker tag finance-frontend:${{ github.sha }} myregistry/finance-frontend:latest
          docker push myregistry/finance-frontend:latest
```

---

## 📝 Environment-Specific Configurations

### Development
- **API URL**: http://localhost:8080/api
- **Logging**: Verbose console logs
- **Source Maps**: Enabled
- **Caching**: Disabled

### Staging
- **API URL**: https://staging-api.myapp.com/api
- **Logging**: Standard logs
- **Source Maps**: Enabled
- **Caching**: Standard

### Production
- **API URL**: https://api.myapp.com/api
- **Logging**: Error logs only
- **Source Maps**: Disabled
- **Caching**: Aggressive
- **Monitoring**: Full APM enabled

---

## 🎯 Performance Benchmarks

### Target Metrics

| Metric | Target | Current |
|--------|--------|---------|
| **First Contentful Paint** | < 1.5s | ~1.2s |
| **Time to Interactive** | < 3.0s | ~2.5s |
| **Lighthouse Score** | > 90 | 95 |
| **Bundle Size** | < 500KB | ~350KB |
| **Docker Image** | < 50MB | ~40MB |
| **Build Time** | < 5min | ~3min |

### Testing Performance

```powershell
# Lighthouse CI
npm install -g @lhci/cli

lhci autorun --collect.url=http://localhost:3000

# Bundle size check
npm run build
Get-ChildItem build/static/js/*.js | Measure-Object -Property Length -Sum
```

---

## 🛠️ Troubleshooting Production Issues

### Issue: High Memory Usage

**Solution**:
```nginx
# nginx.conf - Limit worker processes
worker_processes 1;
worker_rlimit_nofile 1024;

events {
    worker_connections 512;
}
```

### Issue: Slow Response Times

**Check**:
1. CDN configuration
2. Gzip enabled
3. Asset caching headers
4. Backend API response time

### Issue: Failed Health Checks

**Debug**:
```powershell
docker exec -it finance-prod sh
curl localhost/health
nginx -t
ps aux
```

---

## 📚 Additional Resources

- [React Production Build](https://reactjs.org/docs/optimizing-performance.html)
- [Docker Multi-Stage Builds](https://docs.docker.com/build/building/multi-stage/)
- [Nginx Performance Tuning](https://www.nginx.com/blog/tuning-nginx/)
- [Web Vitals](https://web.dev/vitals/)

---

**Last Updated**: February 23, 2026
**Maintained by**: DevOps Team
