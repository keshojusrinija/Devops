# ===================================
# Docker Build & Run Commands
# Quick Reference Guide
# ===================================

# ===================================
# 1️⃣ DEVELOPMENT BUILD & RUN
# ===================================

# Build development image
docker build `
  --build-arg REACT_APP_API_URL=http://localhost:8080/api `
  -t finance-frontend-dev .

# Run development container on port 3000
docker run -d `
  --name finance-dev `
  -p 3000:80 `
  finance-frontend-dev

# Access: http://localhost:3000


# ===================================
# 2️⃣ PRODUCTION BUILD & RUN
# ===================================

# Build production image
docker build `
  --build-arg REACT_APP_API_URL=https://api.myapp.com/api `
  -t finance-frontend-prod .

# Run production container on port 80
docker run -d `
  --name finance-prod `
  -p 80:80 `
  finance-frontend-prod

# Access: http://localhost


# ===================================
# 3️⃣ STAGING BUILD & RUN
# ===================================

# Build staging image
docker build `
  --build-arg REACT_APP_API_URL=https://staging-api.myapp.com/api `
  --build-arg REACT_APP_ENV=staging `
  -t finance-frontend:staging .

# Run staging container
docker run -d `
  --name finance-staging `
  -p 8080:80 `
  finance-frontend:staging


# ===================================
# 4️⃣ VERIFICATION COMMANDS
# ===================================

# Check if container is running
docker ps

# View container logs
docker logs finance-prod

# Follow logs in real-time
docker logs -f finance-prod

# Check container health
docker inspect --format='{{.State.Health.Status}}' finance-prod

# Access container shell
docker exec -it finance-prod sh

# Inside container: Check nginx files
ls -la /usr/share/nginx/html

# Inside container: Search for API URL
grep -r "localhost:8080" /usr/share/nginx/html/static/js/ || echo "Not found"

# Inside container: Test nginx
curl http://localhost

# Inside container: Test health endpoint
curl http://localhost/health

# Exit container
exit


# ===================================
# 5️⃣ TESTING COMMANDS
# ===================================

# Test health endpoint from host
curl http://localhost:3000/health

# Test if API URL is embedded correctly
docker exec finance-prod sh -c "grep -o 'localhost:8080' /usr/share/nginx/html/static/js/*.js | head -n 1"

# Check environment during build (verbose)
docker build `
  --build-arg REACT_APP_API_URL=http://localhost:8080/api `
  --progress=plain `
  -t finance-frontend-test . 2>&1 | Select-String "REACT_APP"


# ===================================
# 6️⃣ CLEANUP COMMANDS
# ===================================

# Stop container
docker stop finance-prod

# Remove container
docker rm finance-prod

# Remove image
docker rmi finance-frontend-prod

# Stop and remove in one command
docker rm -f finance-prod

# Clean up all stopped containers
docker container prune -f

# Clean up unused images
docker image prune -f

# Nuclear option: Remove everything
docker rm -f finance-dev finance-prod finance-staging
docker rmi finance-frontend-dev finance-frontend-prod finance-frontend:staging


# ===================================
# 7️⃣ ADVANCED COMMANDS
# ===================================

# Build with custom tag
docker build `
  --build-arg REACT_APP_API_URL=https://api.myapp.com/api `
  -t finance-frontend:v1.0.0 `
  -t finance-frontend:latest .

# Run with environment variables (note: won't affect built app)
docker run -d `
  --name finance-prod `
  -p 80:80 `
  -e NODE_ENV=production `
  finance-frontend-prod

# Run with restart policy
docker run -d `
  --name finance-prod `
  -p 80:80 `
  --restart unless-stopped `
  finance-frontend-prod

# Run with memory limit
docker run -d `
  --name finance-prod `
  -p 80:80 `
  --memory="512m" `
  --cpus="1" `
  finance-frontend-prod

# View container resource usage
docker stats finance-prod

# Inspect container details
docker inspect finance-prod

# Export logs to file
docker logs finance-prod > logs.txt 2>&1


# ===================================
# 8️⃣ DOCKER COMPOSE (Alternative)
# ===================================

# If you create docker-compose.yml, you can use:
# docker-compose up -d
# docker-compose down
# docker-compose logs -f


# ===================================
# 9️⃣ REGISTRY COMMANDS
# ===================================

# Tag for Docker Hub
docker tag finance-frontend-prod username/finance-frontend:v1.0.0

# Push to Docker Hub
docker push username/finance-frontend:v1.0.0

# Tag for private registry
docker tag finance-frontend-prod myregistry.com/finance-frontend:v1.0.0

# Push to private registry
docker push myregistry.com/finance-frontend:v1.0.0


# ===================================
# 🔟 ONE-LINERS
# ===================================

# Build and run in one line (development)
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance-dev . ; docker run -d --name finance-dev -p 3000:80 finance-dev

# Build and run in one line (production)
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t finance-prod . ; docker run -d --name finance-prod -p 80:80 finance-prod

# Rebuild and restart
docker rm -f finance-prod ; docker rmi finance-frontend-prod ; docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t finance-frontend-prod . ; docker run -d --name finance-prod -p 80:80 finance-frontend-prod


# ===================================
# ⚡ QUICK TESTING WORKFLOW
# ===================================

# 1. Build
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance-test .

# 2. Run
docker run -d --name finance-test -p 3000:80 finance-test

# 3. Open browser
Start-Process "http://localhost:3000"

# 4. Check logs
docker logs finance-test

# 5. Verify API URL
docker exec finance-test sh -c "grep -o 'localhost:8080' /usr/share/nginx/html/static/js/*.js | head -n 1"

# 6. Clean up
docker rm -f finance-test
docker rmi finance-test
