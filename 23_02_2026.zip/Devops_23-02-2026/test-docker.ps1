# ===================================
# Automated Test Script
# Personal Finance Tracker - Docker
# ===================================

Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Personal Finance Tracker - Docker Test" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host ""

# Configuration
$IMAGE_NAME = "finance-frontend-test"
$CONTAINER_NAME = "finance-test-container"
$TEST_PORT = 3001
$API_URL = "http://localhost:8080/api"

# Cleanup function
function Cleanup {
    Write-Host "🧹 Cleaning up..." -ForegroundColor Yellow
    docker rm -f $CONTAINER_NAME 2>$null
    docker rmi $IMAGE_NAME 2>$null
}

# Test 1: Build Image
Write-Host "📦 Test 1: Building Docker image..." -ForegroundColor Green
$buildOutput = docker build `
    --build-arg REACT_APP_API_URL=$API_URL `
    -t $IMAGE_NAME `
    . 2>&1

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Build successful" -ForegroundColor Green
} else {
    Write-Host "❌ Build failed" -ForegroundColor Red
    Write-Host $buildOutput
    exit 1
}

Write-Host ""

# Test 2: Run Container
Write-Host "🚀 Test 2: Running container..." -ForegroundColor Green
docker run -d `
    --name $CONTAINER_NAME `
    -p ${TEST_PORT}:80 `
    $IMAGE_NAME | Out-Null

if ($LASTEXITCODE -eq 0) {
    Write-Host "✅ Container started successfully" -ForegroundColor Green
} else {
    Write-Host "❌ Failed to start container" -ForegroundColor Red
    Cleanup
    exit 1
}

# Wait for container to be ready
Write-Host "⏳ Waiting for container to be ready..."
Start-Sleep -Seconds 3

Write-Host ""

# Test 3: Check if container is running
Write-Host "🔍 Test 3: Checking container status..." -ForegroundColor Green
$containerStatus = docker ps --filter "name=$CONTAINER_NAME" --format "{{.Status}}"

if ($containerStatus -match "Up") {
    Write-Host "✅ Container is running" -ForegroundColor Green
    Write-Host "   Status: $containerStatus" -ForegroundColor Gray
} else {
    Write-Host "❌ Container is not running" -ForegroundColor Red
    docker logs $CONTAINER_NAME
    Cleanup
    exit 1
}

Write-Host ""

# Test 4: Check Health Endpoint
Write-Host "🏥 Test 4: Testing health endpoint..." -ForegroundColor Green
try {
    $healthResponse = Invoke-WebRequest -Uri "http://localhost:$TEST_PORT/health" -UseBasicParsing -TimeoutSec 5
    if ($healthResponse.StatusCode -eq 200 -and $healthResponse.Content -match "healthy") {
        Write-Host "✅ Health check passed" -ForegroundColor Green
        Write-Host "   Response: $($healthResponse.Content)" -ForegroundColor Gray
    } else {
        Write-Host "⚠️ Health check returned unexpected response" -ForegroundColor Yellow
    }
} catch {
    Write-Host "⚠️ Health endpoint not accessible (this might be expected)" -ForegroundColor Yellow
}

Write-Host ""

# Test 5: Check Main Page
Write-Host "🌐 Test 5: Testing main page..." -ForegroundColor Green
try {
    $mainResponse = Invoke-WebRequest -Uri "http://localhost:$TEST_PORT" -UseBasicParsing -TimeoutSec 5
    if ($mainResponse.StatusCode -eq 200) {
        Write-Host "✅ Main page accessible" -ForegroundColor Green
        Write-Host "   Status Code: $($mainResponse.StatusCode)" -ForegroundColor Gray
        
        # Check if HTML contains expected content
        if ($mainResponse.Content -match "root") {
            Write-Host "✅ HTML structure looks correct" -ForegroundColor Green
        }
    }
} catch {
    Write-Host "❌ Main page not accessible" -ForegroundColor Red
    Write-Host "   Error: $_" -ForegroundColor Red
}

Write-Host ""

# Test 6: Verify API URL in Container
Write-Host "🔧 Test 6: Verifying API URL configuration..." -ForegroundColor Green
$apiCheck = docker exec $CONTAINER_NAME sh -c "grep -r 'localhost:8080' /usr/share/nginx/html/static/js/*.js 2>/dev/null | head -n 1"

if ($apiCheck) {
    Write-Host "✅ API URL found in built files" -ForegroundColor Green
    Write-Host "   Found: $apiCheck" -ForegroundColor Gray
} else {
    Write-Host "⚠️ API URL not found (files might be minified)" -ForegroundColor Yellow
}

Write-Host ""

# Test 7: Check Nginx Configuration
Write-Host "📝 Test 7: Checking nginx configuration..." -ForegroundColor Green
$nginxTest = docker exec $CONTAINER_NAME nginx -t 2>&1

if ($nginxTest -match "successful") {
    Write-Host "✅ Nginx configuration is valid" -ForegroundColor Green
} else {
    Write-Host "❌ Nginx configuration has issues" -ForegroundColor Red
    Write-Host $nginxTest
}

Write-Host ""

# Test 8: View Logs
Write-Host "📋 Test 8: Checking container logs..." -ForegroundColor Green
$logs = docker logs $CONTAINER_NAME 2>&1 | Select-Object -First 10

if ($logs) {
    Write-Host "✅ Logs accessible" -ForegroundColor Green
    Write-Host "   First few lines:" -ForegroundColor Gray
    $logs | ForEach-Object { Write-Host "   $_" -ForegroundColor Gray }
} else {
    Write-Host "⚠️ No logs available yet" -ForegroundColor Yellow
}

Write-Host ""

# Summary
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Test Summary" -ForegroundColor Cyan
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Image Name:     $IMAGE_NAME" -ForegroundColor White
Write-Host "Container Name: $CONTAINER_NAME" -ForegroundColor White
Write-Host "Port:           $TEST_PORT" -ForegroundColor White
Write-Host "API URL:        $API_URL" -ForegroundColor White
Write-Host ""
Write-Host "Access the application at: http://localhost:$TEST_PORT" -ForegroundColor Green
Write-Host ""

# Ask if user wants to clean up
Write-Host "=====================================" -ForegroundColor Cyan
$cleanup = Read-Host "Would you like to clean up test resources? (Y/N)"

if ($cleanup -eq 'Y' -or $cleanup -eq 'y') {
    Cleanup
    Write-Host "✅ Cleanup completed" -ForegroundColor Green
} else {
    Write-Host "ℹ️ Test container is still running" -ForegroundColor Blue
    Write-Host ""
    Write-Host "Manual cleanup commands:" -ForegroundColor Yellow
    Write-Host "  docker stop $CONTAINER_NAME" -ForegroundColor Gray
    Write-Host "  docker rm $CONTAINER_NAME" -ForegroundColor Gray
    Write-Host "  docker rmi $IMAGE_NAME" -ForegroundColor Gray
}

Write-Host ""
Write-Host "=====================================" -ForegroundColor Cyan
Write-Host "Testing Complete! 🎉" -ForegroundColor Green
Write-Host "=====================================" -ForegroundColor Cyan
