# 🚀 Quick Start Guide - Personal Finance Tracker

## ⚡ 3-Minute Setup

### Step 1: Clone/Download Project
```powershell
cd c:\Users\malle\OneDrive\Desktop\Devops2026\Devops_23-02-2026
```

### Step 2: Local Development (Optional)
```powershell
npm install
npm start
# Opens at http://localhost:3000
```

### Step 3: Docker Build & Run

#### Development Build
```powershell
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance-dev .
docker run -d --name finance-dev -p 3000:80 finance-dev
Start-Process "http://localhost:3000"
```

#### Production Build
```powershell
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t finance-prod .
docker run -d --name finance-prod -p 80:80 finance-prod
Start-Process "http://localhost"
```

---

## 📁 Project Files Overview

| File | Purpose |
|------|---------|
| **Dockerfile** | Multi-stage build (node → nginx) |
| **nginx.conf** | Nginx config for SPA routing |
| **.env.development** | Dev environment variables |
| **.env.production** | Prod environment variables |
| **src/services/api.js** | API service with validation |
| **src/App.js** | Main React component |
| **README.md** | Full documentation |
| **DOCKER_COMMANDS.md** | All Docker commands |
| **PRODUCTION_GUIDE.md** | Best practices |
| **test-docker.ps1** | Automated test script |

---

## 🎯 Key Features

✅ **Environment-based configuration** (.env files + Docker build args)  
✅ **API validation** (shows error if REACT_APP_API_URL missing)  
✅ **Fallback UI** (graceful error handling)  
✅ **Multi-stage Docker build** (40MB final image)  
✅ **Production-ready nginx** (gzip, caching, security headers)  
✅ **Health checks** (/health endpoint)  
✅ **SPA routing support** (all routes → index.html)  

---

## 🔧 Environment Variables

### Required
- `REACT_APP_API_URL` - Backend API endpoint

### Optional
- `REACT_APP_ENV` - Environment name (dev/staging/prod)

### How to Set

**Local Development:**
Edit `.env.development`
```bash
REACT_APP_API_URL=http://localhost:8080/api
```

**Docker Build:**
```powershell
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t app .
```

---

## 🧪 Testing

### Run Automated Tests
```powershell
.\test-docker.ps1
```

### Manual Verification
```powershell
# Check container is running
docker ps

# View logs
docker logs finance-prod

# Test health endpoint
curl http://localhost:3000/health

# Access shell
docker exec -it finance-prod sh
```

### Browser Console
Press F12 → Console → Look for:
```
🔧 API Configuration: { API_URL: '...', ... }
```

---

## 🎨 UI States

### ✅ Normal Operation
- Shows dashboard with API connection status
- Displays balance and transactions
- "Fetch Data" button to call API

### ⚠️ Missing API Configuration
- Error page: "API Configuration Missing"
- Shows current environment variables
- Instructions to fix

### 🌐 API Unreachable
- Warning page: "API Server Unreachable"
- Shows configured API URL
- Retry button to attempt reconnection

---

## 🐳 Common Docker Commands

```powershell
# Build
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance .

# Run
docker run -d --name finance -p 3000:80 finance

# Stop
docker stop finance

# Remove
docker rm finance

# View logs
docker logs finance

# Access shell
docker exec -it finance sh

# Clean up everything
docker rm -f finance
docker rmi finance
```

---

## 📊 What Happens During Build?

```
1. FROM node:18-alpine          → Start with Node.js image
2. ARG REACT_APP_API_URL        → Accept build argument
3. ENV REACT_APP_API_URL=$...   → Set environment variable
4. npm ci                       → Install dependencies
5. npm run build                → Build React app (API URL baked in)
6. FROM nginx:alpine            → Switch to nginx image
7. COPY --from=build            → Copy built files
8. EXPOSE 80                    → Expose port 80
9. Final image: ~40MB           → Optimized production image
```

---

## 🔍 Verification Checklist

- [ ] Docker image builds successfully
- [ ] Container starts and stays running
- [ ] Health endpoint returns "healthy"
- [ ] Main page loads in browser
- [ ] Console shows API configuration
- [ ] API URL is correct in UI/console
- [ ] Fallback UI works (test with missing API URL)

---

## 📞 Troubleshooting

### Container won't start
```powershell
docker logs finance-prod  # Check error logs
```

### Can't access application
```powershell
docker ps  # Verify port mapping shows 0.0.0.0:3000->80/tcp
```

### API URL not working
```powershell
# Rebuild with correct URL
docker rm -f finance-prod
docker build --build-arg REACT_APP_API_URL=http://correct-url -t finance-prod .
docker run -d --name finance-prod -p 3000:80 finance-prod
```

### Wrong environment displayed
- API URL is baked during build
- Must rebuild with new --build-arg
- Cannot change after build

---

## 📚 Next Steps

1. **Customize API Endpoints**: Edit `src/services/api.js`
2. **Add More Features**: Create new components
3. **Setup Backend**: Ensure backend runs on configured URL
4. **Deploy to Cloud**: Push to Docker registry
5. **Setup CI/CD**: Automate builds and deployments
6. **Add Monitoring**: Integrate APM tools
7. **Configure HTTPS**: Add SSL certificates to nginx

---

## 🎓 Learning Resources

- **Dockerfile**: See comments in `Dockerfile`
- **API Service**: Check `src/services/api.js`
- **Full Docs**: Read `README.md`
- **Best Practices**: Read `PRODUCTION_GUIDE.md`
- **All Commands**: See `DOCKER_COMMANDS.md`

---

## ✨ Features Demonstrated

### React
- Environment variables (`process.env.REACT_APP_*`)
- Conditional rendering (error states)
- Hooks (useState, useEffect)
- API integration with Axios
- Error boundaries

### Docker
- Multi-stage builds
- Build arguments
- Environment variables
- Health checks
- Image optimization

### DevOps
- Environment separation (dev/prod)
- Configuration management
- Container orchestration
- Testing automation
- Documentation

### Nginx
- SPA routing
- Static file serving
- Gzip compression
- Caching strategies
- Security headers

---

## 🎯 Production Deployment Checklist

- [ ] Change API URL to production endpoint
- [ ] Remove console.logs (or use ENV check)
- [ ] Enable HTTPS
- [ ] Configure CDN (optional)
- [ ] Setup monitoring
- [ ] Configure backups
- [ ] Test load balancing
- [ ] Setup CI/CD pipeline
- [ ] Configure auto-scaling
- [ ] Document runbook

---

## 👥 Team Handoff

### For Developers
- Source code in `src/`
- API service: `src/services/api.js`
- Styling: `src/App.css`
- Add new features in `src/`

### For DevOps
- Dockerfile for builds
- nginx.conf for server config
- Environment variables in build args
- Health check at `/health`

### For QA
- Run `test-docker.ps1`
- Test all three UI states
- Verify API integration
- Check error handling

---

**Ready to Go! 🚀**

Run this to get started:
```powershell
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance .
docker run -d --name finance -p 3000:80 finance
Start-Process "http://localhost:3000"
```
