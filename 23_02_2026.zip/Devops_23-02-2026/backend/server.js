// ===================================
// Mock Backend Server for Testing
// Personal Finance Tracker API
// ===================================

const express = require('express');
const cors = require('cors');

const app = express();
const PORT = 8080;

// Middleware
app.use(cors()); // Enable CORS for frontend
app.use(express.json());

// Logging middleware
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
  next();
});

// ===================================
// Mock Data
// ===================================

let transactions = [
  {
    id: 1,
    description: 'Salary',
    amount: 5000,
    category: 'Income',
    date: '2026-02-01'
  },
  {
    id: 2,
    description: 'Rent Payment',
    amount: -1500,
    category: 'Housing',
    date: '2026-02-05'
  },
  {
    id: 3,
    description: 'Grocery Shopping',
    amount: -250,
    category: 'Food',
    date: '2026-02-10'
  },
  {
    id: 4,
    description: 'Coffee Shop',
    amount: -45,
    category: 'Food',
    date: '2026-02-15'
  },
  {
    id: 5,
    description: 'Freelance Project',
    amount: 800,
    category: 'Income',
    date: '2026-02-18'
  }
];

let balance = {
  amount: 4005,
  currency: 'USD',
  lastUpdated: new Date().toISOString()
};

// Budget data
let budgets = [
  { category: 'Food', limit: 500, spent: 295, period: 'monthly' },
  { category: 'Housing', limit: 1500, spent: 1500, period: 'monthly' },
  { category: 'Transportation', limit: 300, spent: 0, period: 'monthly' },
  { category: 'Entertainment', limit: 200, spent: 0, period: 'monthly' }
];

// Categories
const categories = [
  'Income', 'Food', 'Housing', 'Transportation', 
  'Entertainment', 'Shopping', 'Healthcare', 'Education', 
  'Bills', 'Savings', 'Other'
];

// ===================================
// API Routes
// ===================================

// Health Check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    service: 'Personal Finance Tracker API',
    version: '1.0.0'
  });
});

// Get all transactions
app.get('/api/transactions', (req, res) => {
  setTimeout(() => {
    res.json(transactions);
  }, 500); // Simulate network delay
});

// Get single transaction
app.get('/api/transactions/:id', (req, res) => {
  const transaction = transactions.find(t => t.id === parseInt(req.params.id));
  if (transaction) {
    res.json(transaction);
  } else {
    res.status(404).json({ error: 'Transaction not found' });
  }
});

// Create new transaction
app.post('/api/transactions', (req, res) => {
  const newTransaction = {
    id: transactions.length + 1,
    description: req.body.description,
    amount: req.body.amount,
    category: req.body.category,
    date: req.body.date || new Date().toISOString().split('T')[0]
  };
  
  transactions.push(newTransaction);
  
  // Update balance
  balance.amount += newTransaction.amount;
  balance.lastUpdated = new Date().toISOString();
  
  res.status(201).json(newTransaction);
});

// Update transaction
app.put('/api/transactions/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = transactions.findIndex(t => t.id === id);
  
  if (index !== -1) {
    const oldAmount = transactions[index].amount;
    
    transactions[index] = {
      ...transactions[index],
      ...req.body,
      id: id // Ensure ID doesn't change
    };
    
    // Update balance
    const amountDiff = transactions[index].amount - oldAmount;
    balance.amount += amountDiff;
    balance.lastUpdated = new Date().toISOString();
    
    res.json(transactions[index]);
  } else {
    res.status(404).json({ error: 'Transaction not found' });
  }
});

// Delete transaction
app.delete('/api/transactions/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const index = transactions.findIndex(t => t.id === id);
  
  if (index !== -1) {
    const deleted = transactions.splice(index, 1)[0];
    
    // Update balance
    balance.amount -= deleted.amount;
    balance.lastUpdated = new Date().toISOString();
    
    res.json({ message: 'Transaction deleted', transaction: deleted });
  } else {
    res.status(404).json({ error: 'Transaction not found' });
  }
});

// Get balance
app.get('/api/balance', (req, res) => {
  setTimeout(() => {
    res.json(balance);
  }, 300);
});

// Get statistics
app.get('/api/statistics', (req, res) => {
  const period = req.query.period || 'month';
  
  const income = transactions
    .filter(t => t.amount > 0)
    .reduce((sum, t) => sum + t.amount, 0);
  
  const expenses = transactions
    .filter(t => t.amount < 0)
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);
  
  const stats = {
    period,
    income,
    expenses,
    net: income - expenses,
    transactionCount: transactions.length,
    averageTransaction: transactions.length > 0
      ? transactions.reduce((sum, t) => sum + Math.abs(t.amount), 0) / transactions.length
      : 0,
    categories: transactions.reduce((acc, t) => {
      if (!acc[t.category]) {
        acc[t.category] = { count: 0, total: 0 };
      }
      acc[t.category].count++;
      acc[t.category].total += Math.abs(t.amount);
      return acc;
    }, {})
  };
  
  res.json(stats);
});

// Get all categories
app.get('/api/categories', (req, res) => {
  res.json(categories);
});

// Get budgets
app.get('/api/budgets', (req, res) => {
  res.json(budgets);
});

// Create or update budget
app.post('/api/budgets', (req, res) => {
  const { category, limit, period } = req.body;
  
  const existingIndex = budgets.findIndex(b => b.category === category);
  
  // Calculate spent amount for this category
  const spent = Math.abs(
    transactions
      .filter(t => t.category === category && t.amount < 0)
      .reduce((sum, t) => sum + t.amount, 0)
  );
  
  const budget = { category, limit, spent, period: period || 'monthly' };
  
  if (existingIndex !== -1) {
    budgets[existingIndex] = budget;
  } else {
    budgets.push(budget);
  }
  
  res.json(budget);
});

// Delete budget
app.delete('/api/budgets/:category', (req, res) => {
  const category = req.params.category;
  const index = budgets.findIndex(b => b.category === category);
  
  if (index !== -1) {
    const deleted = budgets.splice(index, 1)[0];
    res.json({ message: 'Budget deleted', budget: deleted });
  } else {
    res.status(404).json({ error: 'Budget not found' });
  }
});

// Dashboard summary
app.get('/api/dashboard', (req, res) => {
  const income = transactions
    .filter(t => t.amount > 0)
    .reduce((sum, t) => sum + t.amount, 0);
  
  const expenses = transactions
    .filter(t => t.amount < 0)
    .reduce((sum, t) => sum + Math.abs(t.amount), 0);
  
  const recentTransactions = transactions.slice(-5).reverse();
  
  const categoryBreakdown = transactions
    .filter(t => t.amount < 0)
    .reduce((acc, t) => {
      if (!acc[t.category]) {
        acc[t.category] = 0;
      }
      acc[t.category] += Math.abs(t.amount);
      return acc;
    }, {});
  
  const topCategories = Object.entries(categoryBreakdown)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([category, amount]) => ({ category, amount }));
  
  res.json({
    balance: balance.amount,
    income,
    expenses,
    net: income - expenses,
    transactionCount: transactions.length,
    recentTransactions,
    topCategories,
    budgetSummary: {
      total: budgets.reduce((sum, b) => sum + b.limit, 0),
      spent: budgets.reduce((sum, b) => sum + b.spent, 0),
      remaining: budgets.reduce((sum, b) => sum + (b.limit - b.spent), 0)
    }
  });
});

// Catch-all for undefined routes
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found',
    path: req.path,
    availableEndpoints: [
      'GET /api/health',
      'GET /api/transactions',
      'GET /api/transactions/:id',
      'POST /api/transactions',
      'PUT /api/transactions/:id',
      'DELETE /api/transactions/:id',
      'GET /api/balance',
      'GET /api/statistics'
    ]
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  res.status(500).json({ 
    error: 'Internal server error',
    message: err.message 
  });
});

// ===================================
// Start Server
// ===================================

app.listen(PORT, () => {
  console.log('========================================');
  console.log('🚀 Personal Finance Tracker API');
  console.log('========================================');
  console.log(`✅ Server running on http://localhost:${PORT}`);
  console.log(`✅ API endpoint: http://localhost:${PORT}/api`);
  console.log(`✅ Health check: http://localhost:${PORT}/api/health`);
  console.log('========================================');
  console.log('📊 Available Endpoints:');
  console.log('  GET    /api/health');
  console.log('  GET    /api/transactions');
  console.log('  GET    /api/transactions/:id');
  console.log('  GET    /api/categories');
  console.log('  GET    /api/budgets');
  console.log('  POST   /api/budgets');
  console.log('  DELETE /api/budgets/:category');
  console.log('  GET    /api/dashboard');
  console.log('  POST   /api/transactions');
  console.log('  PUT    /api/transactions/:id');
  console.log('  DELETE /api/transactions/:id');
  console.log('  GET    /api/balance');
  console.log('  GET    /api/statistics');
  console.log('========================================');
  console.log('🔗 Frontend should connect to: http://localhost:8080/api');
  console.log('========================================');
});
