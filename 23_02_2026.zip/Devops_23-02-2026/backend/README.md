# Mock Backend API - Personal Finance Tracker

A simple Express.js mock backend for testing the React frontend.

## Quick Start

```powershell
# Install dependencies
cd backend
npm install

# Start server
npm start
```

Server will run on: **http://localhost:8080**

## API Endpoints

- `GET /api/health` - Health check
- `GET /api/transactions` - Get all transactions
- `GET /api/transactions/:id` - Get single transaction
- `POST /api/transactions` - Create transaction
- `PUT /api/transactions/:id` - Update transaction
- `DELETE /api/transactions/:id` - Delete transaction
- `GET /api/balance` - Get account balance
- `GET /api/statistics` - Get transaction statistics

## Mock Data

The server includes 5 sample transactions:
- Salary: +$5000
- Rent: -$1500
- Groceries: -$250
- Coffee: -$45
- Freelance: +$800

**Total Balance**: $4005

## CORS

CORS is enabled for all origins to allow frontend connections.
