import React, { useState, useEffect } from 'react';
import { 
  isApiConfigured, 
  getApiUrl, 
  checkApiHealth,
  getTransactions,
  getBalance,
  createTransaction,
  updateTransaction,
  deleteTransaction,
  getBudgets,
  getCategories,
  getDashboard
} from './services/api';
import './App.css';

function App() {
  const [apiStatus, setApiStatus] = useState({
    configured: false,
    healthy: false,
    checking: true,
    error: null
  });
  const [transactions, setTransactions] = useState([]);
  const [balance, setBalance] = useState(null);
  const [budgets, setBudgets] = useState([]);
  const [categories, setCategories] = useState([]);
  const [dashboard, setDashboard] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [showTransactionForm, setShowTransactionForm] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [formData, setFormData] = useState({
    description: '',
    amount: '',
    category: 'Food',
    date: new Date().toISOString().split('T')[0]
  });

  // Check API configuration and health on mount
  useEffect(() => {
    const checkApi = async () => {
      const configured = isApiConfigured();
      const apiUrl = getApiUrl();

      console.log('🔍 Checking API Status...');
      console.log('API URL:', apiUrl);
      console.log('Configured:', configured);

      if (!configured) {
        setApiStatus({
          configured: false,
          healthy: false,
          checking: false,
          error: 'API URL not configured'
        });
        return;
      }

      // Check API health
      const healthCheck = await checkApiHealth();
      
      setApiStatus({
        configured: true,
        healthy: healthCheck.success,
        checking: false,
        error: healthCheck.success ? null : 'API is unreachable'
      });
    };

    checkApi();
  }, []);

  // Fetch data from API
  const fetchData = async () => {
    setLoading(true);
    setError(null);

    try {
      // Fetch all data in parallel
      const [transactionsResult, balanceResult, budgetsResult, categoriesResult, dashboardResult] = await Promise.all([
        getTransactions(),
        getBalance(),
        getBudgets(),
        getCategories(),
        getDashboard()
      ]);

      if (transactionsResult.success) {
        setTransactions(transactionsResult.data);
      }

      if (balanceResult.success) {
        setBalance(balanceResult.data);
      }

      if (budgetsResult.success) {
        setBudgets(budgetsResult.data);
      }

      if (categoriesResult.success) {
        setCategories(categoriesResult.data);
      }

      if (dashboardResult.success) {
        setDashboard(dashboardResult.data);
      }
    } catch (err) {
      setError(`Unexpected error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle transaction form submission
  const handleTransactionSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const transactionData = {
      ...formData,
      amount: parseFloat(formData.amount)
    };

    try {
      let result;
      if (editingTransaction) {
        result = await updateTransaction(editingTransaction.id, transactionData);
      } else {
        result = await createTransaction(transactionData);
      }

      if (result.success) {
        setShowTransactionForm(false);
        setEditingTransaction(null);
        setFormData({
          description: '',
          amount: '',
          category: 'Food',
          date: new Date().toISOString().split('T')[0]
        });
        fetchData(); // Refresh data
      } else {
        setError(result.error);
      }
    } catch (err) {
      setError(`Failed to save transaction: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  // Handle delete transaction
  const handleDeleteTransaction = async (id) => {
    if (!window.confirm('Are you sure you want to delete this transaction?')) {
      return;
    }

    setLoading(true);
    const result = await deleteTransaction(id);
    
    if (result.success) {
      fetchData(); // Refresh data
    } else {
      setError(result.error);
    }
    setLoading(false);
  };

  // Handle edit transaction
  const handleEditTransaction = (transaction) => {
    setEditingTransaction(transaction);
    setFormData({
      description: transaction.description,
      amount: Math.abs(transaction.amount).toString(),
      category: transaction.category,
      date: transaction.date
    });
    setShowTransactionForm(true);
  };

  // ===================================
  // Fallback UI: API Not Configured
  // ===================================
  if (!apiStatus.configured) {
    return (
      <div className="App">
        <div className="error-container">
          <div className="error-icon">⚠️</div>
          <h1>API Configuration Missing</h1>
          <p className="error-message">
            The application cannot connect to the backend API because 
            <code>REACT_APP_API_URL</code> is not configured.
          </p>
          <div className="error-details">
            <h3>How to fix this:</h3>
            <ul>
              <li>
                <strong>Development:</strong> Ensure <code>.env.development</code> file exists 
                with <code>REACT_APP_API_URL=http://localhost:8080/api</code>
              </li>
              <li>
                <strong>Production:</strong> Pass the build argument during Docker build:<br/>
                <code>docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t app .</code>
              </li>
            </ul>
          </div>
          <div className="config-info">
            <strong>Current Configuration:</strong>
            <pre>{JSON.stringify({
              REACT_APP_API_URL: process.env.REACT_APP_API_URL || '❌ NOT SET',
              NODE_ENV: process.env.NODE_ENV,
              REACT_APP_ENV: process.env.REACT_APP_ENV || 'not set'
            }, null, 2)}</pre>
          </div>
        </div>
      </div>
    );
  }

  // ===================================
  // Fallback UI: API Unreachable
  // ===================================
  if (!apiStatus.healthy && !apiStatus.checking) {
    return (
      <div className="App">
        <div className="warning-container">
          <div className="warning-icon">🌐</div>
          <h1>API Server Unreachable</h1>
          <p className="warning-message">
            The frontend is configured correctly, but cannot connect to the backend API.
          </p>
          <div className="api-info">
            <strong>API URL:</strong> <code>{getApiUrl()}</code>
          </div>
          <div className="error-details">
            <h3>Possible causes:</h3>
            <ul>
              <li>Backend server is not running</li>
              <li>Network connectivity issues</li>
              <li>Incorrect API URL configuration</li>
              <li>CORS issues (check browser console)</li>
            </ul>
          </div>
          <button onClick={() => window.location.reload()} className="retry-button">
            🔄 Retry Connection
          </button>
        </div>
      </div>
    );
  }

  // ===================================
  // Main Application UI
  // ===================================
  return (
    <div className="App">
      <header className="App-header">
        <h1>💰 Personal Finance Tracker</h1>
        <div className="api-status">
          <span className="status-indicator success">●</span>
          API Connected: <code>{getApiUrl()}</code>
        </div>
      </header>

      <main className="App-main">
        {/* Action Buttons */}
        <div className="action-bar">
          <button 
            onClick={fetchData} 
            disabled={loading}
            className="btn btn-primary"
          >
            {loading ? '⏳ Loading...' : '🔄 Refresh Data'}
          </button>
          <button 
            onClick={() => {
              setShowTransactionForm(!showTransactionForm);
              setEditingTransaction(null);
              setFormData({
                description: '',
                amount: '',
                category: categories[0] || 'Food',
                date: new Date().toISOString().split('T')[0]
              });
            }}
            className="btn btn-success"
          >
            {showTransactionForm ? '❌ Cancel' : '➕ Add Transaction'}
          </button>
        </div>

        {/* Transaction Form */}
        {showTransactionForm && (
          <div className="card transaction-form">
            <h2>{editingTransaction ? '✏️ Edit Transaction' : '➕ Add New Transaction'}</h2>
            <form onSubmit={handleTransactionSubmit}>
              <div className="form-group">
                <label>Description:</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  required
                  placeholder="e.g., Grocery shopping"
                />
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Amount ($):</label>
                  <input
                    type="number"
                    step="0.01"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    required
                    placeholder="0.00"
                  />
                  <small>Use positive for income, negative for expenses</small>
                </div>
                
                <div className="form-group">
                  <label>Category:</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  >
                    {categories.map(cat => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
                
                <div className="form-group">
                  <label>Date:</label>
                  <input
                    type="date"
                    value={formData.date}
                    onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                    required
                  />
                </div>
              </div>
              
              <div className="form-actions">
                <button type="submit" className="btn btn-primary" disabled={loading}>
                  {loading ? '⏳ Saving...' : editingTransaction ? '💾 Update' : '➕ Add'}
                </button>
                <button 
                  type="button" 
                  className="btn btn-secondary"
                  onClick={() => {
                    setShowTransactionForm(false);
                    setEditingTransaction(null);
                  }}
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Dashboard Overview */}
        {dashboard && (
          <section className="dashboard-overview">
            <div className="stats-grid">
              <div className="stat-card income">
                <div className="stat-icon">💵</div>
                <div className="stat-content">
                  <div className="stat-label">Total Income</div>
                  <div className="stat-value">${dashboard.income.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="stat-card expenses">
                <div className="stat-icon">💸</div>
                <div className="stat-content">
                  <div className="stat-label">Total Expenses</div>
                  <div className="stat-value">${dashboard.expenses.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="stat-card balance">
                <div className="stat-icon">💰</div>
                <div className="stat-content">
                  <div className="stat-label">Current Balance</div>
                  <div className="stat-value">${dashboard.balance.toFixed(2)}</div>
                </div>
              </div>
              
              <div className="stat-card net">
                <div className="stat-icon">📊</div>
                <div className="stat-content">
                  <div className="stat-label">Net Income</div>
                  <div className="stat-value" style={{ color: dashboard.net >= 0 ? '#10b981' : '#ef4444' }}>
                    ${dashboard.net.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          </section>
        )}

        {/* Budget Tracking */}
        {budgets.length > 0 && (
          <div className="card budget-card">
            <h2>📊 Budget Tracking</h2>
            <div className="budget-list">
              {budgets.map(budget => {
                const percentage = (budget.spent / budget.limit) * 100;
                const isOverBudget = percentage > 100;
                return (
                  <div key={budget.category} className="budget-item">
                    <div className="budget-header">
                      <span className="budget-category">{budget.category}</span>
                      <span className="budget-amount">
                        ${budget.spent.toFixed(2)} / ${budget.limit.toFixed(2)}
                      </span>
                    </div>
                    <div className="budget-progress">
                      <div 
                        className={`budget-progress-bar ${isOverBudget ? 'over-budget' : ''}`}
                        style={{ width: `${Math.min(percentage, 100)}%` }}
                      />
                    </div>
                    <div className="budget-footer">
                      <span className={isOverBudget ? 'over-budget-text' : ''}>
                        {isOverBudget ? '⚠️ Over budget' : `${(100 - percentage).toFixed(0)}% remaining`}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Transactions List */}
        <div className="card">
          <h2>📝 All Transactions ({transactions.length})</h2>
          {transactions.length > 0 ? (
            <div className="transactions-table">
              <table>
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Description</th>
                    <th>Category</th>
                    <th>Amount</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.slice().reverse().map((transaction) => (
                    <tr key={transaction.id}>
                      <td>{transaction.date}</td>
                      <td>{transaction.description}</td>
                      <td><span className="category-badge">{transaction.category}</span></td>
                      <td>
                        <span className={transaction.amount > 0 ? 'positive' : 'negative'}>
                          {transaction.amount > 0 ? '+' : ''}${transaction.amount.toFixed(2)}
                        </span>
                      </td>
                      <td>
                        <button 
                          className="btn-icon btn-edit"
                          onClick={() => handleEditTransaction(transaction)}
                          title="Edit"
                        >
                          ✏️
                        </button>
                        <button 
                          className="btn-icon btn-delete"
                          onClick={() => handleDeleteTransaction(transaction.id)}
                          title="Delete"
                        >
                          🗑️
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="empty-state">No transactions yet. Click "Refresh Data" or add a new transaction!</p>
          )}
        </div>

        {/* Top Categories */}
        {dashboard && dashboard.topCategories && dashboard.topCategories.length > 0 && (
          <div className="card">
            <h2>🏆 Top Spending Categories</h2>
            <div className="category-chart">
              {dashboard.topCategories.map((item, index) => (
                <div key={item.category} className="category-bar">
                  <div className="category-info">
                    <span className="category-rank">#{index + 1}</span>
                    <span className="category-name">{item.category}</span>
                    <span className="category-amount">${item.amount.toFixed(2)}</span>
                  </div>
                  <div className="category-bar-fill" style={{
                    width: `${(item.amount / dashboard.topCategories[0].amount) * 100}%`
                  }} />
                </div>
              ))}
            </div>
          </div>
        )}

        {error && (
          <div className="error-message">
            <strong>⚠️ Error:</strong> {error}
          </div>
        )}

        {/* Debug Info */}
        <section className="debug-info">
          <h3>🔧 Debug Information</h3>
          <table>
            <tbody>
              <tr>
                <td><strong>API URL:</strong></td>
                <td><code>{getApiUrl()}</code></td>
              </tr>
              <tr>
                <td><strong>Environment:</strong></td>
                <td><code>{process.env.REACT_APP_ENV || process.env.NODE_ENV}</code></td>
              </tr>
              <tr>
                <td><strong>API Status:</strong></td>
                <td>
                  <span className={`status-badge ${apiStatus.healthy ? 'success' : 'error'}`}>
                    {apiStatus.healthy ? '✅ Healthy' : '❌ Unhealthy'}
                  </span>
                </td>
              </tr>
              <tr>
                <td><strong>Transactions:</strong></td>
                <td>{transactions.length}</td>
              </tr>
              <tr>
                <td><strong>Categories:</strong></td>
                <td>{categories.length}</td>
              </tr>
            </tbody>
          </table>
        </section>
      </main>
    </div>
  );
}

export default App;
