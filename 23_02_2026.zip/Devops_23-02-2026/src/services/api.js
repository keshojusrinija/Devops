import axios from 'axios';

/**
 * API Configuration Service
 * Handles all API calls with environment-based configuration
 */

// ===================================
// 1️⃣ Environment Variable Validation
// ===================================

const API_URL = process.env.REACT_APP_API_URL;

// Validate API URL is configured
if (!API_URL) {
  console.error(
    '🚨 ERROR: REACT_APP_API_URL is not defined!',
    '\nPlease ensure you have set REACT_APP_API_URL in your environment variables.',
    '\nFor development: Check .env.development file',
    '\nFor production: Pass --build-arg REACT_APP_API_URL during Docker build'
  );
}

// Log the current configuration (helpful for debugging)
console.log('🔧 API Configuration:', {
  API_URL: API_URL || '❌ NOT CONFIGURED',
  Environment: process.env.REACT_APP_ENV || process.env.NODE_ENV,
  Timestamp: new Date().toISOString()
});

// ===================================
// 2️⃣ Axios Instance Configuration
// ===================================

const apiClient = axios.create({
  baseURL: API_URL,
  timeout: 10000, // 10 second timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request Interceptor - Add auth tokens, logging, etc.
apiClient.interceptors.request.use(
  (config) => {
    console.log(`📤 API Request: ${config.method?.toUpperCase()} ${config.url}`);
    // Add authorization token if available
    const token = localStorage.getItem('authToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    console.error('📤 Request Error:', error);
    return Promise.reject(error);
  }
);

// Response Interceptor - Handle errors globally
apiClient.interceptors.response.use(
  (response) => {
    console.log(`📥 API Response: ${response.config.url} - Status: ${response.status}`);
    return response;
  },
  (error) => {
    if (error.code === 'ECONNABORTED') {
      console.error('⏱️ Request timeout - API took too long to respond');
    } else if (error.response) {
      // Server responded with error status
      console.error(`📥 API Error Response: ${error.response.status}`, error.response.data);
    } else if (error.request) {
      // Request made but no response received
      console.error('🌐 Network Error: No response from API server', {
        message: error.message,
        apiUrl: API_URL
      });
    } else {
      console.error('❌ Request Setup Error:', error.message);
    }
    return Promise.reject(error);
  }
);

// ===================================
// 3️⃣ API Service Functions
// ===================================

/**
 * Check if API is configured
 */
export const isApiConfigured = () => {
  return !!API_URL;
};

/**
 * Get the API URL (for display/debugging)
 */
export const getApiUrl = () => {
  return API_URL || null;
};

/**
 * Health check - Test API connectivity
 */
export const checkApiHealth = async () => {
  try {
    const response = await apiClient.get('/health');
    console.log('✅ API Health Check: Connected successfully');
    return { success: true, data: response.data };
  } catch (error) {
    console.error('❌ API Health Check: Failed to connect', error);
    return { 
      success: false, 
      error: error.message,
      isApiUnreachable: true 
    };
  }
};

// ===================================
// 4️⃣ Finance Tracker API Endpoints
// ===================================

/**
 * Get all transactions
 */
export const getTransactions = async () => {
  try {
    const response = await apiClient.get('/transactions');
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Create a new transaction
 */
export const createTransaction = async (transactionData) => {
  try {
    const response = await apiClient.post('/transactions', transactionData);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Update a transaction
 */
export const updateTransaction = async (id, transactionData) => {
  try {
    const response = await apiClient.put(`/transactions/${id}`, transactionData);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Delete a transaction
 */
export const deleteTransaction = async (id) => {
  try {
    const response = await apiClient.delete(`/transactions/${id}`);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Get account balance
 */
export const getBalance = async () => {
  try {
    const response = await apiClient.get('/balance');
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Get transaction statistics
 */
export const getStatistics = async (period = 'month') => {
  try {
    const response = await apiClient.get('/statistics', {
      params: { period }
    });
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Get all categories
 */
export const getCategories = async () => {
  try {
    const response = await apiClient.get('/categories');
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Get all budgets
 */
export const getBudgets = async () => {
  try {
    const response = await apiClient.get('/budgets');
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Create or update budget
 */
export const saveBudget = async (budgetData) => {
  try {
    const response = await apiClient.post('/budgets', budgetData);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Delete budget
 */
export const deleteBudget = async (category) => {
  try {
    const response = await apiClient.delete(`/budgets/${category}`);
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

/**
 * Get dashboard summary
 */
export const getDashboard = async () => {
  try {
    const response = await apiClient.get('/dashboard');
    return { success: true, data: response.data };
  } catch (error) {
    return { 
      success: false, 
      error: error.response?.data?.message || error.message 
    };
  }
};

// Export the axios instance for custom requests
export default apiClient;
