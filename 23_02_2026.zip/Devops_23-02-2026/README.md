# 💰 Personal Finance Tracker - Frontend

A production-ready React frontend application with Docker support and environment-based configuration.

## 📋 Table of Contents

- [Project Structure](#project-structure)
- [Environment Configuration](#environment-configuration)
- [Local Development](#local-development)
- [Docker Build & Deployment](#docker-build--deployment)
- [Testing & Validation](#testing--validation)
- [Production Best Practices](#production-best-practices)
- [Troubleshooting](#troubleshooting)

---

## 📁 Project Structure

```
personal-finance-tracker/
├── public/
│   └── index.html              # HTML template
├── src/
│   ├── services/
│   │   └── api.js              # API service with validation
│   ├── App.js                  # Main React component
│   ├── App.css                 # Application styles
│   ├── index.js                # React entry point
│   └── index.css               # Global styles
├── .env.development            # Development environment variables
├── .env.production             # Production environment variables
├── Dockerfile                  # Multi-stage Docker build
├── nginx.conf                  # Nginx configuration for production
├── .dockerignore               # Docker ignore rules
├── package.json                # Node.js dependencies
└── README.md                   # This file
```

---

## 🔧 Environment Configuration

### Environment Variables

The application uses `REACT_APP_API_URL` to configure the backend API endpoint.

#### `.env.development`
```bash
REACT_APP_API_URL=http://localhost:8080/api
REACT_APP_ENV=development
```

#### `.env.production`
```bash
REACT_APP_API_URL=https://api.myapp.com/api
REACT_APP_ENV=production
```

### How Environment Variables Work

1. **Development**: Variables are read from `.env.development` when running `npm start`
2. **Production**: Variables are passed as build arguments during Docker build
3. **Validation**: The API service validates the presence of `REACT_APP_API_URL` and shows error messages if missing

---

## 💻 Local Development

### Prerequisites

- Node.js 18+ and npm
- Git (optional)

### Installation

```powershell
# Install dependencies
npm install
```

### Running Development Server

```powershell
# Start development server (uses .env.development)
npm start
```

The app will open at `http://localhost:3000`

### What You'll See

- ✅ If `REACT_APP_API_URL` is configured: Main application UI
- ⚠️ If `REACT_APP_API_URL` is missing: Error message with clear instructions
- 🌐 If API is unreachable: Warning message with retry option

---

## 🐳 Docker Build & Deployment

### Build Commands

#### Development Build

```powershell
docker build `
  --build-arg REACT_APP_API_URL=http://localhost:8080/api `
  -t finance-frontend-dev .
```

#### Production Build

```powershell
docker build `
  --build-arg REACT_APP_API_URL=https://api.myapp.com/api `
  -t finance-frontend-prod .
```

### Run Commands

#### Development Container

```powershell
# Run on port 3000
docker run -d `
  --name finance-frontend-dev `
  -p 3000:80 `
  finance-frontend-dev
```

#### Production Container

```powershell
# Run on port 80
docker run -d `
  --name finance-frontend-prod `
  -p 80:80 `
  finance-frontend-prod
```

#### Run on Custom Port

```powershell
# Run on port 8080
docker run -d `
  --name finance-frontend `
  -p 8080:80 `
  finance-frontend-prod
```

### Docker Commands Reference

```powershell
# View running containers
docker ps

# View logs
docker logs finance-frontend-prod

# Follow logs in real-time
docker logs -f finance-frontend-prod

# Stop container
docker stop finance-frontend-prod

# Remove container
docker rm finance-frontend-prod

# Remove image
docker rmi finance-frontend-prod
```

---

## 🧪 Testing & Validation

### 1️⃣ Verify Environment Variables Inside Container

```powershell
# Access container shell
docker exec -it finance-frontend-prod sh

# Inside container, check nginx files
cd /usr/share/nginx/html

# View main.*.js file (contains baked-in env vars)
ls -la static/js/

# Search for API URL in built files
grep -r "REACT_APP_API_URL" . 2>/dev/null || echo "Built successfully"

# Exit container
exit
```

### 2️⃣ Check Application in Browser

```powershell
# If running on port 3000
Start-Process "http://localhost:3000"

# If running on port 80
Start-Process "http://localhost"
```

### 3️⃣ Browser Console Testing

Open browser DevTools (F12) and check the console:

```javascript
// You should see these logs:
// "🔧 API Configuration: { API_URL: 'your-api-url', ... }"
// "🔍 Checking API Status..."
// "API URL: your-configured-url"
```

### 4️⃣ Test API Connection

In the browser console, you can manually test the API:

```javascript
// Check if API is configured
console.log(process.env.REACT_APP_API_URL);

// Test fetch request
fetch(process.env.REACT_APP_API_URL + '/health')
  .then(response => response.json())
  .then(data => console.log('✅ API Response:', data))
  .catch(error => console.error('❌ API Error:', error));
```

### 5️⃣ Health Check

```powershell
# Check container health status
docker inspect --format='{{.State.Health.Status}}' finance-frontend-prod

# Test nginx health endpoint
curl http://localhost:3000/health
# Should return: "healthy"
```

### 6️⃣ Verify API URL in Built Files

```powershell
# Extract and search built JavaScript files
docker exec finance-frontend-prod sh -c "grep -o 'localhost:8080' /usr/share/nginx/html/static/js/*.js | head -n 1"

# Or for production
docker exec finance-frontend-prod sh -c "grep -o 'api.myapp.com' /usr/share/nginx/html/static/js/*.js | head -n 1"
```

---

## 📊 Testing Scenarios

### Scenario 1: Missing API Configuration

**Test**: Build without `--build-arg`

```powershell
docker build -t finance-frontend-test .
docker run -p 3001:80 finance-frontend-test
```

**Expected Result**: Application shows "API Configuration Missing" error page

### Scenario 2: API Server Unreachable

**Test**: Configure valid URL but backend is down

**Expected Result**: Application shows "API Server Unreachable" warning with retry button

### Scenario 3: Successful Connection

**Test**: Configure valid URL with running backend

**Expected Result**: Application loads successfully with API connection status

---

## 🏗️ Production Best Practices

### ✅ What This Setup Provides

1. **Multi-Stage Build**
   - Smaller final image (nginx:alpine ~40MB vs node:18 ~180MB)
   - No source code in production image
   - Faster deployment and reduced attack surface

2. **Environment Isolation**
   - Separate configs for dev/prod
   - No hardcoded URLs in source code
   - Easy to change environments at build time

3. **Error Handling**
   - Validation of required environment variables
   - Graceful fallback UI for missing config
   - Clear error messages for developers

4. **Security**
   - Security headers in nginx config
   - No exposed source maps in production
   - HTTPS-ready configuration

5. **Performance**
   - Gzip compression enabled
   - Static asset caching (1 year)
   - No cache for index.html (ensures updates)

6. **Monitoring**
   - Health check endpoint (`/health`)
   - Comprehensive logging
   - API connectivity status in UI

7. **Developer Experience**
   - Console logging for debugging
   - Debug panel in UI
   - Clear build-time feedback

---

## 🔄 Complete Workflow Example

### Development to Production Pipeline

```powershell
# 1. Develop locally
npm install
npm start

# 2. Test development build
docker build `
  --build-arg REACT_APP_API_URL=http://localhost:8080/api `
  -t finance-frontend:dev .

docker run -p 3000:80 finance-frontend:dev

# 3. Test production build
docker build `
  --build-arg REACT_APP_API_URL=https://api.myapp.com/api `
  -t finance-frontend:v1.0.0 .

docker run -p 80:80 finance-frontend:v1.0.0

# 4. Verify in browser
Start-Process "http://localhost"

# 5. Tag for registry
docker tag finance-frontend:v1.0.0 myregistry.com/finance-frontend:v1.0.0

# 6. Push to registry
docker push myregistry.com/finance-frontend:v1.0.0
```

---

## 🐛 Troubleshooting

### Issue: "API Configuration Missing" Error

**Cause**: `REACT_APP_API_URL` not provided during build

**Solution**:
```powershell
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t app .
```

### Issue: "API Server Unreachable" Warning

**Causes**:
1. Backend server is not running
2. Incorrect API URL
3. Network/firewall issues
4. CORS not configured on backend

**Solutions**:
1. Ensure backend is running and accessible
2. Verify API URL is correct
3. Check browser console for CORS errors
4. Test API directly: `curl http://your-api-url/health`

### Issue: Environment Variables Not Working Locally

**Cause**: `.env.development` not being read

**Solutions**:
1. Ensure file is named exactly `.env.development`
2. Restart development server (`npm start`)
3. Clear React cache: `rm -rf node_modules/.cache`

### Issue: Container Exits Immediately

**Diagnosis**:
```powershell
docker logs finance-frontend-prod
```

**Common Causes**:
- Build failed (check build logs)
- Nginx configuration error

### Issue: Cannot Access Application

**Check Port Mapping**:
```powershell
docker ps
# Verify PORTS column shows: 0.0.0.0:3000->80/tcp
```

**Check Container Logs**:
```powershell
docker logs finance-frontend-prod
```

**Test Nginx Inside Container**:
```powershell
docker exec finance-frontend-prod curl localhost
```

---

## 📚 Additional Resources

### API Service Features

The `src/services/api.js` file provides:

- ✅ Environment variable validation
- ✅ Request/response logging
- ✅ Error handling with interceptors
- ✅ Timeout configuration (10 seconds)
- ✅ Authentication token support
- ✅ Health check function
- ✅ Typed error responses

### Example API Usage

```javascript
import { 
  getTransactions, 
  createTransaction, 
  getBalance,
  checkApiHealth 
} from './services/api';

// Check API health
const health = await checkApiHealth();
console.log(health.success); // true or false

// Fetch transactions
const result = await getTransactions();
if (result.success) {
  console.log('Transactions:', result.data);
} else {
  console.error('Error:', result.error);
}

// Create transaction
const newTransaction = {
  description: 'Coffee',
  amount: -5.50,
  category: 'Food'
};

const created = await createTransaction(newTransaction);
if (created.success) {
  console.log('Created:', created.data);
}
```

---

## 🎯 Key Features Summary

| Feature | Implementation |
|---------|----------------|
| **Environment Management** | `.env.development`, `.env.production` |
| **API Validation** | Runtime check with error UI |
| **Docker Multi-Stage** | Build (node:18) → Serve (nginx:alpine) |
| **Error Handling** | Fallback UI, loading states, error messages |
| **Logging** | Console logs for API calls |
| **Health Checks** | Docker healthcheck + `/health` endpoint |
| **Security** | Security headers, no source exposure |
| **Performance** | Gzip, caching, optimized build |
| **Router Support** | SPA routing with nginx fallback |

---

## 📝 Build Arguments Reference

```dockerfile
# Available build arguments
ARG REACT_APP_API_URL     # Backend API URL (required)
ARG REACT_APP_ENV         # Environment name (optional)
```

**Example with multiple args**:
```powershell
docker build `
  --build-arg REACT_APP_API_URL=https://api.myapp.com/api `
  --build-arg REACT_APP_ENV=staging `
  -t finance-frontend:staging .
```

---

## 🚀 Quick Start Commands

```powershell
# Local Development
npm install
npm start

# Docker Development Build
docker build --build-arg REACT_APP_API_URL=http://localhost:8080/api -t finance-dev .
docker run -p 3000:80 finance-dev

# Docker Production Build
docker build --build-arg REACT_APP_API_URL=https://api.myapp.com/api -t finance-prod .
docker run -p 80:80 finance-prod

# Test in Browser
Start-Process "http://localhost:3000"
```

---

## 📞 Support

For issues or questions:
1. Check browser console for errors
2. Check Docker logs: `docker logs <container-name>`
3. Verify environment variables are set correctly
4. Test API endpoint directly with curl/Postman

---

**Built with ❤️ by DevOps Team**

Last Updated: February 23, 2026
