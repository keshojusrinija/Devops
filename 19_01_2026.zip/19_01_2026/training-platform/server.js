const app = require('./app');
const connectDB = require('./config/db');

const PORT = 3000;

connectDB();

app.listen(PORT, () => {
  console.log('====================================');
  console.log('🚀 Training Platform Server Running');
  console.log(`Base URL : http://localhost:${PORT}`);
  console.log('');
  console.log('AVAILABLE API ENDPOINTS:');
  console.log(`GET     → http://localhost:${PORT}/`);
  console.log(`POST    → http://localhost:${PORT}/courses`);
  console.log(`GET     → http://localhost:${PORT}/courses`);
  console.log(`GET     → http://localhost:${PORT}/courses/:id`);
  console.log(`PUT     → http://localhost:${PORT}/courses/:id`);
  console.log(`DELETE  → http://localhost:${PORT}/courses/:id`);
  console.log('====================================');
});
