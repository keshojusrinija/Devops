const mongoose = require('mongoose');

const enrollmentSchema = new mongoose.Schema({
  courseId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Course'
  },
  studentName: String
});

module.exports = mongoose.model('Enrollment', enrollmentSchema);
