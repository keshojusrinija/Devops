const courseService = require('../services/courseService');

exports.getCourses = (req, res) => {
  res.json(courseService.getAllCourses());
};
