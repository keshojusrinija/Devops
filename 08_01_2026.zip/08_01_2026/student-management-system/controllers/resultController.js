const resultService = require('../services/resultService');

exports.getResults = (req, res) => {
  const results = resultService.getStudentResults(req.params.studentId);
  res.json(results);
};
