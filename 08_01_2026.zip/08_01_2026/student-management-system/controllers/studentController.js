const studentService = require('../services/studentService');

exports.registerStudent = (req, res) => {
  const student = studentService.addStudent(req.body);
  res.status(201).json(student);
};

exports.getStudents = (req, res) => {
  res.json(studentService.getAllStudents());
};
