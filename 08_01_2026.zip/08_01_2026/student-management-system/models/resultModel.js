class Result {
  constructor(studentId, subject, grade) {
    this.studentId = studentId;
    this.subject = subject;
    this.grade = grade;
  }
}

module.exports = Result;
