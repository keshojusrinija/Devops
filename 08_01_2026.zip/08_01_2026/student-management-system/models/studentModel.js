class Student {
  constructor(id, name, course) {
    this.id = id;
    this.name = name;
    this.course = course;
  }
}

module.exports = Student;
