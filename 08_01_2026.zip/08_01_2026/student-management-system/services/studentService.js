const students = [];

exports.addStudent = (student) => {
  students.push(student);
  return student;
};

exports.getAllStudents = () => students;
