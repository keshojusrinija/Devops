const express = require('express');
const app = express();

app.use(express.json());

// HOME ROUTE
app.get('/', (req, res) => {
  res.send('Student Management System API is running');
});

// MODULE ROUTES
app.use('/students', require('./routes/studentRoutes'));
app.use('/courses', require('./routes/courseRoutes'));
app.use('/results', require('./routes/resultRoutes'));

module.exports = app;
